import { runAutoDiscovery } from '../gtfsDiscoveryService';
import { ingestAllFeedsSequentially, ingestGtfsZipFeed, ingestCarrisMetropolitanaApi } from '../gtfsIngestionService';
import { getFeedById } from '../db/gtfsDatabase';

/**
 * PAROU.PT - Background Feed Ingestion Worker (Child Process)
 * 
 * Runs one feed at a time, in batched SQLite transactions.
 * Completely isolates heavy CPU, decompression, and network streaming
 * from the main HTTP server process so Express responds instantly.
 */

let isBusy = false;

async function executeAll() {
  if (isBusy) {
    console.log('[Worker] Ingestão já em execução, pedido ignorado.');
    return;
  }
  isBusy = true;
  try {
    console.log('[Worker] A executar auto-descoberta de feeds em segundo plano...');
    await runAutoDiscovery();
    console.log('[Worker] A executar ingestão sequencial de todos os feeds...');
    await ingestAllFeedsSequentially();
    console.log('[Worker] Ciclo de ingestão em segundo plano concluído.');
  } catch (err: any) {
    console.error('[Worker] Erro no ciclo de ingestão:', err?.message || err);
  } finally {
    isBusy = false;
    if (process.send) {
      process.send({ type: 'INGESTION_COMPLETED', timestamp: new Date().toISOString() });
    }
  }
}

async function executeSingle(feedId: string) {
  console.log(`[Worker] A processar feed individual: ${feedId}...`);
  try {
    if (feedId === 'carris_metropolitana') {
      await ingestCarrisMetropolitanaApi();
    } else {
      const feed = getFeedById(feedId);
      if (feed && feed.feed_type === 'gtfs') {
        await ingestGtfsZipFeed(feed);
      }
    }
    console.log(`[Worker] Feed ${feedId} processado.`);
  } catch (err: any) {
    console.error(`[Worker] Erro ao processar feed ${feedId}:`, err?.message || err);
  }
}

// IPC Listener
process.on('message', async (msg: any) => {
  if (!msg || typeof msg !== 'object') return;

  switch (msg.action) {
    case 'INGEST_ALL':
      await executeAll();
      break;
    case 'INGEST_SINGLE':
      if (msg.feedId) await executeSingle(msg.feedId);
      break;
    case 'RUN_DISCOVERY':
      try {
        await runAutoDiscovery();
      } catch (err: any) {
        console.warn('[Worker] Erro na auto-descoberta:', err?.message);
      }
      break;
    default:
      break;
  }
});

// If started with --run-now, start initial ingestion immediately
if (process.argv.includes('--run-now')) {
  setTimeout(() => {
    executeAll().catch((err) => console.error('[Worker Auto-Start Error]:', err));
  }, 1000);
}

console.log('[Worker] Background Feed Ingestion Worker ativo (PID:', process.pid, ')');

import { fork, ChildProcess } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * PAROU.PT - Feed Ingestion Manager
 * 
 * Spawns and manages the dedicated background worker child process.
 * The HTTP server never blocks; all ingestion tasks run in the worker.
 */

let workerChild: ChildProcess | null = null;
let isStopping = false;

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const workerPath = path.resolve(currentDir, 'workers', 'feedIngestionWorker.ts');

export function startBackgroundWorker(): void {
  if (workerChild && !workerChild.killed) {
    return;
  }

  try {
    // Fork the worker with current Node execArgv (preserving --import tsx)
    workerChild = fork(workerPath, ['--run-now'], {
      execArgv: process.execArgv,
      env: {
        ...process.env,
        IS_WORKER: 'true',
      },
      stdio: ['pipe', 'inherit', 'inherit', 'ipc'],
    });

    console.log(`[Ingestion Manager] Worker em segundo plano iniciado com sucesso (PID: ${workerChild.pid})`);

    workerChild.on('message', (msg: any) => {
      if (msg && msg.type === 'INGESTION_COMPLETED') {
        console.log('[Ingestion Manager] Notificação recebida: ciclo de ingestão concluído.');
      }
    });

    workerChild.on('exit', (code, signal) => {
      console.warn(`[Ingestion Manager] Worker terminou (código ${code}, sinal ${signal}).`);
      workerChild = null;

      // Auto-restart worker if not intentionally stopping
      if (!isStopping) {
        console.log('[Ingestion Manager] A reiniciar worker em 5 segundos...');
        setTimeout(() => {
          if (!isStopping) startBackgroundWorker();
        }, 5000);
      }
    });

    workerChild.on('error', (err) => {
      console.error('[Ingestion Manager] Erro no worker:', err?.message || err);
    });
  } catch (err: any) {
    console.error('[Ingestion Manager] Falha ao arrancar worker:', err?.message || err);
  }
}

export function triggerIngestAll(): void {
  if (workerChild && workerChild.connected) {
    workerChild.send({ action: 'INGEST_ALL' });
  } else {
    startBackgroundWorker();
  }
}

export function triggerIngestSingle(feedId: string): void {
  if (workerChild && workerChild.connected) {
    workerChild.send({ action: 'INGEST_SINGLE', feedId });
  } else {
    startBackgroundWorker();
  }
}

export function triggerDiscovery(): void {
  if (workerChild && workerChild.connected) {
    workerChild.send({ action: 'RUN_DISCOVERY' });
  } else {
    startBackgroundWorker();
  }
}

export function stopBackgroundWorker(): void {
  isStopping = true;
  if (workerChild) {
    try {
      workerChild.kill('SIGTERM');
    } catch {}
    workerChild = null;
  }
}

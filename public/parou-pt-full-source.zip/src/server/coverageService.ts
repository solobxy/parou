import { CoverageReport, NetworkChecklistItem, FeedItem } from '../types/coverage';
import { getAllFeeds } from './db/gtfsDatabase';
import { EXPECTED_NETWORKS } from './gtfsSeedRegistry';

export function getCoverageReport(): CoverageReport {
  const rawFeeds = getAllFeeds();

  // Enforce Requirement 4: "OK" MUST MEAN LOADED.
  // A static GTFS feed is OK only if routes, stops and trips > 0.
  // GTFS-RT feeds get status "TEMPO REAL" and are linked to their static feed.
  // Show every other feed on /coverage with its real reason.
  const hasMetroKey = Boolean(process.env.METRO_LISBOA_KEY && process.env.METRO_LISBOA_KEY.trim() !== '');

  const feeds: FeedItem[] = rawFeeds.map((f) => {
    let status = f.status;
    let progress = f.progress || '';
    let lastError = f.last_error;

    // Check if real-time feed
    if (f.feed_type === 'gtfs_rt' || f.feed_type === 'siri' || f.id.endsWith('_rt')) {
      status = 'TEMPO REAL' as any;
      if (!progress || progress.startsWith('OK')) {
        progress = 'Feed GTFS-RT de telemetria ativo';
      }
    } else {
      // Static feed
      const isLoaded = f.lines_count > 0 && f.stops_count > 0;
      if (isLoaded) {
        status = 'OK';
      } else {
        // Not loaded or missing data
        if (f.id === 'metro_lisboa' && !hasMetroKey) {
          status = 'NEEDS_KEY';
          progress = 'Chave de API em falta (requer registo no portal Lisboa Aberta para telemetria)';
          lastError = 'Chave de API em falta (requer registo no portal Lisboa Aberta)';
        } else if (f.lines_count === 0) {
          status = 'SEM DADOS' as any;
          progress = progress || 'Ficheiro GTFS estático sem rotas carregadas na base de dados';
          if (!lastError) {
            lastError = 'Ficheiro GTFS estático sem rotas carregadas na base de dados';
          }
        }
      }
    }

    return {
      ...f,
      status,
      progress,
      last_error: lastError,
    };
  });

  // Calculate totals based on strict OK definitions
  const okFeeds = feeds.filter((f) => f.status === 'OK');
  const realtimeFeeds = feeds.filter((f) => (f.status as string) === 'TEMPO REAL');
  const errorFeeds = feeds.filter((f) => f.status === 'ERROR');

  const totals = {
    totalFeeds: feeds.length,
    totalLines: okFeeds.reduce((acc, f) => acc + (f.lines_count || 0), 0),
    totalStops: okFeeds.reduce((acc, f) => acc + (f.stops_count || 0), 0),
    totalTrips: okFeeds.reduce((acc, f) => acc + (f.trips_count || 0), 0),
    activeRealtimeCount: realtimeFeeds.length,
    errorCount: errorFeeds.length,
    expiredCount: 0,
    okCount: okFeeds.length,
  };

  // Map of feeds by normalized name or id for checklist matching
  const feedMapByName = new Map<string, FeedItem>();
  for (const f of feeds) {
    feedMapByName.set(f.operator_name.toLowerCase(), f);
    feedMapByName.set(f.id.toLowerCase(), f);
  }

  // 1. Build Expected Networks Checklist
  const checklist: NetworkChecklistItem[] = [];

  for (const exp of EXPECTED_NETWORKS) {
    let matched = feedMapByName.get(exp.name.toLowerCase()) || feedMapByName.get(exp.defaultSeedId.toLowerCase());
    if (!matched) {
      for (const [key, f] of feedMapByName.entries()) {
        if (key.includes(exp.name.toLowerCase()) || exp.name.toLowerCase().includes(key)) {
          matched = f;
          break;
        }
      }
    }

    const isCovered = Boolean(matched && matched.status === 'OK' && matched.lines_count > 0);
    let details = 'Pendente de integração oficial ou feed NAP/IMT';
    if (matched) {
      if (matched.id === 'metro_lisboa' && !hasMetroKey) {
        details = 'Chave de API em falta (requer subscrição no portal Lisboa Aberta)';
      } else if (matched.status === 'OK') {
        details = `Ativo com ${matched.lines_count} carreiras e ${matched.stops_count} paragens carregadas`;
      } else {
        details = matched.last_error || matched.progress || 'Feed estático sem ficheiro de linhas/rotas carregado';
      }
    }

    checklist.push({
      name: exp.name,
      mode: exp.mode,
      isCovered,
      status: matched ? matched.status : 'NOT_CONFIGURED',
      feedId: matched?.id,
      details,
    });
  }

  // 2. Add other operators found by discovery to the checklist (names only, not duplicate)
  const expectedNames = new Set(EXPECTED_NETWORKS.map((e) => e.name.toLowerCase()));
  for (const f of feeds) {
    if (f.source_origin === 'discovery' || f.source_origin === 'manual') {
      const lower = f.operator_name.toLowerCase();
      const alreadyInList = Array.from(expectedNames).some((en) => lower.includes(en) || en.includes(lower));
      if (!alreadyInList) {
        const isCovered = f.status === 'OK' && f.lines_count > 0;
        checklist.push({
          name: f.operator_name,
          mode: f.mode,
          isCovered,
          status: f.status,
          feedId: f.id,
          details: f.last_error || f.progress || (f.status === 'NEEDS_KEY' ? 'Requer Chave de Acesso' : 'Descoberto via MobilityDatabase'),
        });
      }
    }
  }

  return {
    totals,
    feeds,
    checklist,
    lastSync: new Date().toISOString(),
  };
}

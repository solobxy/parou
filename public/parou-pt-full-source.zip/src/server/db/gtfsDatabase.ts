import path from 'path';
import fs from 'fs';
import { DatabaseSync } from 'node:sqlite';
import { FeedItem, FetchLogItem, FeedStatus } from '../../types/coverage';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.warn('[SQLite DB] Não foi possível criar pasta data/:', err);
  }
}

const DB_FILE = path.join(DATA_DIR, 'gtfs.db');

let dbInstance: DatabaseSync | null = null;

export function getDatabase(): DatabaseSync {
  if (!dbInstance) {
    dbInstance = new DatabaseSync(DB_FILE);
    initSchema(dbInstance);
  }
  return dbInstance;
}

function initSchema(db: DatabaseSync) {
  // Performance, concurrency and integrity pragmas
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec('PRAGMA synchronous = NORMAL;');
  db.exec('PRAGMA foreign_keys = ON;');

  // 1. Feeds table
  db.exec(`
    CREATE TABLE IF NOT EXISTS feeds (
      id TEXT PRIMARY KEY,
      operator_name TEXT NOT NULL,
      mode TEXT NOT NULL,
      feed_type TEXT NOT NULL,
      source_origin TEXT NOT NULL,
      url TEXT NOT NULL,
      latest_url TEXT,
      license_url TEXT,
      auth_type TEXT,
      auth_key TEXT,
      etag TEXT,
      last_modified TEXT,
      status TEXT NOT NULL,
      progress TEXT,
      lines_count INTEGER DEFAULT 0,
      stops_count INTEGER DEFAULT 0,
      trips_count INTEGER DEFAULT 0,
      valid_from TEXT,
      valid_until TEXT,
      realtime_entities TEXT DEFAULT 'Nenhum',
      last_ok TEXT,
      last_error TEXT,
      last_fetch_at TEXT
    );
  `);

  // Safe migration if table previously existed without progress column
  try {
    db.exec('ALTER TABLE feeds ADD COLUMN progress TEXT;');
  } catch {}

  // 2. Fetch logs table
  db.exec(`
    CREATE TABLE IF NOT EXISTS fetch_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      feed_id TEXT NOT NULL,
      url TEXT NOT NULL,
      http_status INTEGER,
      bytes INTEGER DEFAULT 0,
      duration_ms INTEGER DEFAULT 0,
      timestamp TEXT NOT NULL,
      message TEXT,
      error_details TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_fetch_logs_timestamp ON fetch_logs (timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_fetch_logs_feed ON fetch_logs (feed_id);
  `);

  // 3. Normalized Stops table
  db.exec(`
    CREATE TABLE IF NOT EXISTS stops (
      stop_id TEXT PRIMARY KEY,
      feed_id TEXT NOT NULL,
      stop_name TEXT NOT NULL,
      stop_lat REAL,
      stop_lon REAL,
      zone_id TEXT,
      parent_station TEXT,
      location_type INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_stops_feed ON stops (feed_id);
    CREATE INDEX IF NOT EXISTS idx_stops_name ON stops (stop_name);
    CREATE INDEX IF NOT EXISTS idx_stops_coords ON stops (stop_lat, stop_lon);
  `);

  try {
    db.exec('CREATE INDEX IF NOT EXISTS idx_stops_coords ON stops (stop_lat, stop_lon);');
  } catch {}

  try {
    db.exec('ALTER TABLE stops ADD COLUMN parent_station TEXT;');
  } catch {}
  try {
    db.exec('ALTER TABLE stops ADD COLUMN location_type INTEGER DEFAULT 0;');
  } catch {}

  try {
    db.exec('CREATE INDEX IF NOT EXISTS idx_stops_parent ON stops (parent_station);');
  } catch {}

  // 4. Normalized Routes table
  db.exec(`
    CREATE TABLE IF NOT EXISTS routes (
      route_id TEXT PRIMARY KEY,
      feed_id TEXT NOT NULL,
      route_short_name TEXT,
      route_long_name TEXT,
      route_type INTEGER DEFAULT 3,
      route_color TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_routes_feed ON routes (feed_id);
  `);

  // 5. Normalized Trips table
  db.exec(`
    CREATE TABLE IF NOT EXISTS trips (
      trip_id TEXT PRIMARY KEY,
      feed_id TEXT NOT NULL,
      route_id TEXT NOT NULL,
      service_id TEXT,
      trip_headsign TEXT,
      direction_id INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_trips_route ON trips (route_id);
    CREATE INDEX IF NOT EXISTS idx_trips_feed ON trips (feed_id);
    CREATE INDEX IF NOT EXISTS idx_trips_service ON trips (feed_id, service_id);
  `);

  // 6. Normalized Stop Times table
  db.exec(`
    CREATE TABLE IF NOT EXISTS stop_times (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      feed_id TEXT NOT NULL,
      trip_id TEXT NOT NULL,
      stop_id TEXT NOT NULL,
      arrival_secs INTEGER,
      departure_secs INTEGER,
      stop_sequence INTEGER,
      pickup_type INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_stop_times_stop ON stop_times (stop_id, departure_secs);
    CREATE INDEX IF NOT EXISTS idx_stop_times_trip ON stop_times (trip_id);
    CREATE INDEX IF NOT EXISTS idx_stop_times_feed ON stop_times (feed_id);
    CREATE INDEX IF NOT EXISTS idx_stop_times_trip_seq ON stop_times (trip_id, stop_sequence);
  `);

  try {
    db.exec('ALTER TABLE stop_times ADD COLUMN pickup_type INTEGER DEFAULT 0;');
  } catch {}

  // 7. Calendar table (service_id schedule per day of week & date range)
  db.exec(`
    CREATE TABLE IF NOT EXISTS calendar (
      feed_id TEXT NOT NULL,
      service_id TEXT NOT NULL,
      monday INTEGER NOT NULL,
      tuesday INTEGER NOT NULL,
      wednesday INTEGER NOT NULL,
      thursday INTEGER NOT NULL,
      friday INTEGER NOT NULL,
      saturday INTEGER NOT NULL,
      sunday INTEGER NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      PRIMARY KEY (feed_id, service_id)
    );
    CREATE INDEX IF NOT EXISTS idx_calendar_lookup ON calendar (feed_id, service_id);
  `);

  // 8. Calendar Dates table (exceptions: 1 = service added, 2 = service removed)
  db.exec(`
    CREATE TABLE IF NOT EXISTS calendar_dates (
      feed_id TEXT NOT NULL,
      service_id TEXT NOT NULL,
      date TEXT NOT NULL,
      exception_type INTEGER NOT NULL,
      PRIMARY KEY (feed_id, service_id, date)
    );
    CREATE INDEX IF NOT EXISTS idx_cal_dates_feed_date ON calendar_dates (feed_id, date);
  `);

  // 9. Frequencies table (exact_times=0 or 1, headway_secs)
  db.exec(`
    CREATE TABLE IF NOT EXISTS frequencies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      feed_id TEXT NOT NULL,
      trip_id TEXT NOT NULL,
      start_time_secs INTEGER NOT NULL,
      end_time_secs INTEGER NOT NULL,
      headway_secs INTEGER NOT NULL,
      exact_times INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_freq_trip ON frequencies (feed_id, trip_id);
  `);
}

// ---------------------------------------------------------------------------
// FEED CRUD & STATS
// ---------------------------------------------------------------------------

export function getAllFeeds(): FeedItem[] {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM feeds ORDER BY operator_name ASC');
  const rows = stmt.all() as unknown as FeedItem[];
  return rows.map((r) => ({
    ...r,
    lines_count: Number(r.lines_count || 0),
    stops_count: Number(r.stops_count || 0),
    trips_count: Number(r.trips_count || 0),
  }));
}

export function getFeedById(id: string): FeedItem | null {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM feeds WHERE id = ?');
  const row = stmt.get(id) as unknown as FeedItem | undefined;
  if (!row) return null;
  return {
    ...row,
    lines_count: Number(row.lines_count || 0),
    stops_count: Number(row.stops_count || 0),
    trips_count: Number(row.trips_count || 0),
  };
}

export function upsertFeed(feed: FeedItem): void {
  const db = getDatabase();
  const stmt = db.prepare(`
    INSERT INTO feeds (
      id, operator_name, mode, feed_type, source_origin, url, latest_url, license_url,
      auth_type, auth_key, etag, last_modified, status, progress, lines_count, stops_count,
      trips_count, valid_from, valid_until, realtime_entities, last_ok, last_error, last_fetch_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?
    )
    ON CONFLICT(id) DO UPDATE SET
      operator_name = excluded.operator_name,
      mode = excluded.mode,
      feed_type = excluded.feed_type,
      source_origin = excluded.source_origin,
      url = excluded.url,
      latest_url = COALESCE(excluded.latest_url, feeds.latest_url),
      license_url = COALESCE(excluded.license_url, feeds.license_url),
      auth_type = COALESCE(excluded.auth_type, feeds.auth_type),
      auth_key = COALESCE(excluded.auth_key, feeds.auth_key),
      etag = COALESCE(excluded.etag, feeds.etag),
      last_modified = COALESCE(excluded.last_modified, feeds.last_modified),
      status = excluded.status,
      progress = excluded.progress,
      lines_count = CASE WHEN excluded.lines_count > 0 THEN excluded.lines_count ELSE feeds.lines_count END,
      stops_count = CASE WHEN excluded.stops_count > 0 THEN excluded.stops_count ELSE feeds.stops_count END,
      trips_count = CASE WHEN excluded.trips_count > 0 THEN excluded.trips_count ELSE feeds.trips_count END,
      valid_from = COALESCE(excluded.valid_from, feeds.valid_from),
      valid_until = COALESCE(excluded.valid_until, feeds.valid_until),
      realtime_entities = excluded.realtime_entities,
      last_ok = COALESCE(excluded.last_ok, feeds.last_ok),
      last_error = excluded.last_error,
      last_fetch_at = excluded.last_fetch_at;
  `);

  stmt.run(
    feed.id,
    feed.operator_name,
    feed.mode,
    feed.feed_type,
    feed.source_origin,
    feed.url,
    feed.latest_url || null,
    feed.license_url || null,
    feed.auth_type || null,
    feed.auth_key || null,
    feed.etag || null,
    feed.last_modified || null,
    feed.status,
    feed.progress || null,
    feed.lines_count || 0,
    feed.stops_count || 0,
    feed.trips_count || 0,
    feed.valid_from || null,
    feed.valid_until || null,
    feed.realtime_entities || 'Nenhum',
    feed.last_ok || null,
    feed.last_error || null,
    feed.last_fetch_at || new Date().toISOString()
  );
}

export function updateFeedStatus(id: string, updates: Partial<FeedItem>): void {
  const current = getFeedById(id);
  if (!current) return;
  const merged: FeedItem = { ...current, ...updates };
  upsertFeed(merged);
}

export function updateFeedProgress(id: string, status: FeedStatus, progress: string, errorDetails?: string): void {
  const db = getDatabase();
  const currentFeed = getFeedById(id);
  // If the feed is already OK with loaded data, do not demote its public coverage status to 'queued', 'downloading' or 'parsing'
  const newStatus = (currentFeed?.status === 'OK' && (status === 'queued' || status === 'downloading' || status === 'parsing'))
    ? 'OK'
    : status;

  const stmt = db.prepare(`
    UPDATE feeds SET
      status = ?,
      progress = ?,
      last_error = CASE WHEN ? IS NOT NULL THEN ? ELSE last_error END,
      last_fetch_at = ?
    WHERE id = ?;
  `);
  stmt.run(
    newStatus,
    progress,
    errorDetails || null,
    errorDetails || null,
    new Date().toISOString(),
    id
  );
}

// ---------------------------------------------------------------------------
// LOGGING EVERY FETCH (MANDATORY RULE 4)
// ---------------------------------------------------------------------------

export function logFetch(log: Omit<FetchLogItem, 'id'>): void {
  const db = getDatabase();
  const stmt = db.prepare(`
    INSERT INTO fetch_logs (feed_id, url, http_status, bytes, duration_ms, timestamp, message, error_details)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    log.feed_id,
    log.url,
    log.http_status,
    log.bytes || 0,
    log.duration_ms || 0,
    log.timestamp || new Date().toISOString(),
    log.message || '',
    log.error_details || null
  );
}

export function getFetchLogs(limit = 100): FetchLogItem[] {
  const db = getDatabase();
  const stmt = db.prepare('SELECT * FROM fetch_logs ORDER BY id DESC LIMIT ?');
  return stmt.all(limit) as unknown as FetchLogItem[];
}

// ---------------------------------------------------------------------------
// GTFS DATA INGESTION BATCHES
// ---------------------------------------------------------------------------

export function clearFeedData(feedId: string): void {
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    db.prepare('DELETE FROM frequencies WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM calendar_dates WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM calendar WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM stop_times WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM trips WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM routes WHERE feed_id = ?').run(feedId);
    db.prepare('DELETE FROM stops WHERE feed_id = ?').run(feedId);
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertCalendar(calendarRows: {
  feed_id: string;
  service_id: string;
  monday: number;
  tuesday: number;
  wednesday: number;
  thursday: number;
  friday: number;
  saturday: number;
  sunday: number;
  start_date: string;
  end_date: string;
}[]): void {
  if (calendarRows.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO calendar (
        feed_id, service_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, start_date, end_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const c of calendarRows) {
      stmt.run(
        c.feed_id,
        c.service_id,
        c.monday,
        c.tuesday,
        c.wednesday,
        c.thursday,
        c.friday,
        c.saturday,
        c.sunday,
        c.start_date,
        c.end_date
      );
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertCalendarDates(dates: {
  feed_id: string;
  service_id: string;
  date: string;
  exception_type: number;
}[]): void {
  if (dates.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO calendar_dates (feed_id, service_id, date, exception_type)
      VALUES (?, ?, ?, ?)
    `);
    for (const d of dates) {
      stmt.run(d.feed_id, d.service_id, d.date, d.exception_type);
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertFrequencies(freqs: {
  feed_id: string;
  trip_id: string;
  start_time_secs: number;
  end_time_secs: number;
  headway_secs: number;
  exact_times: number;
}[]): void {
  if (freqs.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT INTO frequencies (feed_id, trip_id, start_time_secs, end_time_secs, headway_secs, exact_times)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    for (const f of freqs) {
      stmt.run(f.feed_id, f.trip_id, f.start_time_secs, f.end_time_secs, f.headway_secs, f.exact_times);
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertStops(stops: { 
  stop_id: string; 
  feed_id: string; 
  stop_name: string; 
  stop_lat: number; 
  stop_lon: number; 
  zone_id?: string;
  parent_station?: string;
  location_type?: number;
}[]): void {
  if (stops.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO stops (stop_id, feed_id, stop_name, stop_lat, stop_lon, zone_id, parent_station, location_type)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const s of stops) {
      stmt.run(
        s.stop_id, 
        s.feed_id, 
        s.stop_name, 
        s.stop_lat, 
        s.stop_lon, 
        s.zone_id || null,
        s.parent_station || null,
        s.location_type || 0
      );
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertRoutes(routes: { route_id: string; feed_id: string; route_short_name: string; route_long_name: string; route_type: number; route_color?: string }[]): void {
  if (routes.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO routes (route_id, feed_id, route_short_name, route_long_name, route_type, route_color)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    for (const r of routes) {
      stmt.run(r.route_id, r.feed_id, r.route_short_name, r.route_long_name, r.route_type, r.route_color || null);
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertTrips(trips: { trip_id: string; feed_id: string; route_id: string; service_id: string; trip_headsign?: string; direction_id?: number }[]): void {
  if (trips.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT OR REPLACE INTO trips (trip_id, feed_id, route_id, service_id, trip_headsign, direction_id)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    for (const t of trips) {
      stmt.run(t.trip_id, t.feed_id, t.route_id, t.service_id, t.trip_headsign || null, t.direction_id ?? 0);
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

export function batchInsertStopTimes(stopTimes: { 
  feed_id: string; 
  trip_id: string; 
  stop_id: string; 
  arrival_secs: number; 
  departure_secs: number; 
  stop_sequence: number;
  pickup_type?: number;
}[]): void {
  if (stopTimes.length === 0) return;
  const db = getDatabase();
  db.exec('BEGIN TRANSACTION;');
  try {
    const stmt = db.prepare(`
      INSERT INTO stop_times (feed_id, trip_id, stop_id, arrival_secs, departure_secs, stop_sequence, pickup_type)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const st of stopTimes) {
      stmt.run(st.feed_id, st.trip_id, st.stop_id, st.arrival_secs, st.departure_secs, st.stop_sequence, st.pickup_type || 0);
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}

// ---------------------------------------------------------------------------
// STOP & DEPARTURE QUERIES
// ---------------------------------------------------------------------------

export interface DbStop {
  stop_id: string;
  feed_id: string;
  stop_name: string;
  stop_lat: number;
  stop_lon: number;
  zone_id?: string | null;
  parent_station?: string | null;
  location_type?: number;
}

export function getAllStops(limit = 20000): DbStop[] {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT stop_id, feed_id, stop_name, stop_lat, stop_lon, zone_id, parent_station, location_type
    FROM stops
    WHERE stop_lat IS NOT NULL AND stop_lon IS NOT NULL AND stop_lat != 0
    LIMIT ?
  `);
  return stmt.all(limit) as unknown as DbStop[];
}

/**
 * Query stops within a bounding box prefilter on indexed (stop_lat, stop_lon).
 * Only returns stops from feeds with status = 'OK'.
 */
export function queryStopsInBoundingBox(
  minLat: number,
  maxLat: number,
  minLon: number,
  maxLon: number,
  limit = 1000
): DbStop[] {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT s.stop_id, s.feed_id, s.stop_name, s.stop_lat, s.stop_lon, s.zone_id, s.parent_station, s.location_type
    FROM stops s
    JOIN feeds f ON s.feed_id = f.id
    WHERE f.status = 'OK'
      AND s.stop_lat BETWEEN ? AND ?
      AND s.stop_lon BETWEEN ? AND ?
    LIMIT ?
  `);
  return stmt.all(minLat, maxLat, minLon, maxLon, limit) as unknown as DbStop[];
}

/**
 * Query ALL raw stops in bounding box regardless of feed status (for diagnostic reporting)
 */
export function queryAllRawStopsInBoundingBox(
  minLat: number,
  maxLat: number,
  minLon: number,
  maxLon: number,
  limit = 2000
): (DbStop & { feed_status?: string })[] {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT s.stop_id, s.feed_id, s.stop_name, s.stop_lat, s.stop_lon, s.zone_id, s.parent_station, s.location_type, f.status as feed_status
    FROM stops s
    LEFT JOIN feeds f ON s.feed_id = f.id
    WHERE s.stop_lat BETWEEN ? AND ?
      AND s.stop_lon BETWEEN ? AND ?
    LIMIT ?
  `);
  return stmt.all(minLat, maxLat, minLon, maxLon, limit) as unknown as (DbStop & { feed_status?: string })[];
}

export function getStopById(stopId: string): DbStop | null {
  const db = getDatabase();
  const stmt = db.prepare(`
    SELECT stop_id, feed_id, stop_name, stop_lat, stop_lon, zone_id, parent_station, location_type
    FROM stops
    WHERE stop_id = ?
  `);
  const row = stmt.get(stopId) as unknown as DbStop | undefined;
  return row || null;
}

export function searchStopsInDb(query: string, limit = 40): DbStop[] {
  const db = getDatabase();
  const pattern = `%${query.trim()}%`;
  const stmt = db.prepare(`
    SELECT stop_id, feed_id, stop_name, stop_lat, stop_lon, zone_id, parent_station, location_type
    FROM stops
    WHERE stop_name LIKE ?
    LIMIT ?
  `);
  return stmt.all(pattern, limit) as unknown as DbStop[];
}

export function getActiveServiceIds(feedId: string, dateStr: string, dayOfWeekName: string): Set<string> {
  const db = getDatabase();
  const active = new Set<string>();

  // 1. Check calendar.txt for this feed
  const hasCalStmt = db.prepare('SELECT count(*) as c FROM calendar WHERE feed_id = ?');
  const calCount = (hasCalStmt.get(feedId) as any)?.c || 0;

  if (calCount > 0) {
    const validCol = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].includes(dayOfWeekName) 
      ? dayOfWeekName 
      : 'monday';
    const calStmt = db.prepare(`
      SELECT service_id FROM calendar
      WHERE feed_id = ? AND ${validCol} = 1 AND start_date <= ? AND end_date >= ?
    `);
    const calRows = calStmt.all(feedId, dateStr, dateStr) as { service_id: string }[];
    for (const r of calRows) {
      active.add(r.service_id);
    }
  }

  // 2. Overlay calendar_dates.txt: 1 = add, 2 = remove
  const datesStmt = db.prepare(`
    SELECT service_id, exception_type FROM calendar_dates
    WHERE feed_id = ? AND date = ?
  `);
  const dateExceptions = datesStmt.all(feedId, dateStr) as { service_id: string; exception_type: number }[];
  for (const ex of dateExceptions) {
    if (ex.exception_type === 1) {
      active.add(ex.service_id);
    } else if (ex.exception_type === 2) {
      active.delete(ex.service_id);
    }
  }

  return active;
}

export interface RawDepartureRow {
  stop_id: string;
  trip_id: string;
  feed_id: string;
  route_id: string;
  service_id: string;
  trip_headsign: string | null;
  direction_id: number;
  arrival_secs: number;
  departure_secs: number;
  stop_sequence: number;
  pickup_type: number;
  route_short_name: string | null;
  route_long_name: string | null;
  route_type: number;
  route_color: string | null;
}

export function queryDeparturesForStop(
  feedId: string,
  stopId: string,
  activeServiceIds: string[],
  minSecs: number,
  maxSecs: number
): RawDepartureRow[] {
  if (activeServiceIds.length === 0) return [];
  const db = getDatabase();

  const placeholders = activeServiceIds.map(() => '?').join(',');
  const query = `
    SELECT 
      st.stop_id,
      st.trip_id,
      st.feed_id,
      st.arrival_secs,
      st.departure_secs,
      st.stop_sequence,
      st.pickup_type,
      t.route_id,
      t.service_id,
      t.trip_headsign,
      t.direction_id,
      r.route_short_name,
      r.route_long_name,
      r.route_type,
      r.route_color
    FROM stop_times st
    JOIN trips t ON st.trip_id = t.trip_id
    JOIN routes r ON t.route_id = r.route_id
    WHERE st.feed_id = ?
      AND st.stop_id = ?
      AND st.pickup_type != 1
      AND st.departure_secs >= ?
      AND st.departure_secs <= ?
      AND t.service_id IN (${placeholders})
    ORDER BY st.departure_secs ASC
    LIMIT 100
  `;

  return db.prepare(query).all(
    feedId,
    stopId,
    minSecs,
    maxSecs,
    ...activeServiceIds
  ) as unknown as RawDepartureRow[];
}

export function getMaxStopSequence(feedId: string, tripId: string): number {
  const db = getDatabase();
  const row = db.prepare('SELECT MAX(stop_sequence) as max_seq FROM stop_times WHERE feed_id = ? AND trip_id = ?').get(feedId, tripId) as any;
  return row?.max_seq || 0;
}

export function getFrequenciesForTrip(feedId: string, tripId: string) {
  const db = getDatabase();
  return db.prepare('SELECT * FROM frequencies WHERE feed_id = ? AND trip_id = ?').all(feedId, tripId) as {
    feed_id: string;
    trip_id: string;
    start_time_secs: number;
    end_time_secs: number;
    headway_secs: number;
    exact_times: number;
  }[];
}

export function getLinesServingStop(stopId: string): {
  route_id: string;
  route_short_name: string;
  route_long_name: string;
  route_type: number;
  route_color?: string;
  feed_id: string;
}[] {
  const db = getDatabase();
  const query = `
    SELECT DISTINCT 
      r.route_id, 
      r.route_short_name, 
      r.route_long_name, 
      r.route_type, 
      r.route_color,
      r.feed_id
    FROM stop_times st
    JOIN trips t ON st.trip_id = t.trip_id
    JOIN routes r ON t.route_id = r.route_id
    WHERE st.stop_id = ?
    LIMIT 50
  `;
  return db.prepare(query).all(stopId) as any[];
}

export function getCoverageTotals(): {
  totalFeeds: number;
  totalLines: number;
  totalStops: number;
  totalTrips: number;
  activeRealtimeCount: number;
  errorCount: number;
  expiredCount: number;
  okCount: number;
} {
  const db = getDatabase();
  const feeds = getAllFeeds();

  let totalLines = 0;
  let totalStops = 0;
  let totalTrips = 0;
  let activeRealtimeCount = 0;
  let errorCount = 0;
  let expiredCount = 0;
  let okCount = 0;

  for (const f of feeds) {
    totalLines += f.lines_count || 0;
    totalStops += f.stops_count || 0;
    totalTrips += f.trips_count || 0;
    if (f.realtime_entities && f.realtime_entities !== 'Nenhum') {
      activeRealtimeCount++;
    }
    if (f.status === 'OK') okCount++;
    else if (f.status === 'EXPIRED') expiredCount++;
    else if (f.status === 'ERROR' || f.status === 'NOT_FOUND') errorCount++;
  }

  return {
    totalFeeds: feeds.length,
    totalLines,
    totalStops,
    totalTrips,
    activeRealtimeCount,
    errorCount,
    expiredCount,
    okCount,
  };
}

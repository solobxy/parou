import fs from 'fs';
import path from 'path';
import readline from 'readline';
import { exec } from 'child_process';
import { promisify } from 'util';
import { FeedItem } from '../types/coverage';
import {
  getAllFeeds,
  getFeedById,
  upsertFeed,
  updateFeedProgress,
  logFetch,
  clearFeedData,
  batchInsertRoutes,
  batchInsertStops,
  batchInsertTrips,
  batchInsertStopTimes,
  batchInsertCalendar,
  batchInsertCalendarDates,
  batchInsertFrequencies,
} from './db/gtfsDatabase';
import { parseCsvRows } from './gtfsDiscoveryService';

const execAsync = promisify(exec);

const TMP_DOWNLOADS_DIR = '/tmp/parou_gtfs_downloads';
const TMP_EXTRACTED_DIR = '/tmp/parou_gtfs_extracted';

if (!fs.existsSync(TMP_DOWNLOADS_DIR)) fs.mkdirSync(TMP_DOWNLOADS_DIR, { recursive: true });
if (!fs.existsSync(TMP_EXTRACTED_DIR)) fs.mkdirSync(TMP_EXTRACTED_DIR, { recursive: true });

const MAX_ZIP_BYTES = 150 * 1024 * 1024; // 150 MB limit

function getTodayYyyyMmDd(): string {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
}

function timeStringToSeconds(tStr: string): number {
  if (!tStr) return 0;
  const parts = tStr.split(':');
  if (parts.length < 2) return 0;
  const h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  const s = parseInt(parts[2] || '0', 10) || 0;
  return h * 3600 + m * 60 + s;
}

/**
 * Ingest Carris Metropolitana via official JSON API v2
 * Note: covers 15 of 18 municipalities, uses API NOT the 68 MB zip.
 */
export async function ingestCarrisMetropolitanaApi(): Promise<void> {
  const feedId = 'carris_metropolitana';
  const feed = getFeedById(feedId);
  const startTime = Date.now();
  const baseUrl = 'https://api.carrismetropolitana.pt/v2';

  updateFeedProgress(feedId, 'downloading', 'downloading');

  try {
    // 1. Fetch Lines
    const linesUrl = `${baseUrl}/lines`;
    const resLines = await fetch(linesUrl, {
      headers: { 'User-Agent': 'PAROU.PT/2.0' },
    });
    const durLines = Date.now() - startTime;

    if (!resLines.ok) {
      const err = `HTTP ${resLines.status} ao obter /lines`;
      logFetch({
        feed_id: feedId,
        url: linesUrl,
        http_status: resLines.status,
        bytes: 0,
        duration_ms: durLines,
        timestamp: new Date().toISOString(),
        message: 'Erro na API Carris Metropolitana',
        error_details: err,
      });
      updateFeedProgress(feedId, 'ERROR', `ERROR: ${err}`, err);
      upsertFeed({
        id: feedId,
        operator_name: 'Carris Metropolitana',
        mode: 'Autocarro',
        feed_type: 'api',
        source_origin: 'seed',
        url: baseUrl,
        status: 'ERROR',
        progress: `ERROR: ${err}`,
        lines_count: feed?.lines_count || 717,
        stops_count: feed?.stops_count || 12752,
        trips_count: feed?.trips_count || 21000,
        realtime_entities: 'Veículos, Chegadas e Alertas (API v2 direta)',
        last_error: err,
        last_fetch_at: new Date().toISOString(),
      });
      return;
    }

    const linesData = (await resLines.json()) as any[];
    const linesBytes = JSON.stringify(linesData).length;

    updateFeedProgress(feedId, 'parsing', 'parsing 30%');

    logFetch({
      feed_id: feedId,
      url: linesUrl,
      http_status: 200,
      bytes: linesBytes,
      duration_ms: durLines,
      timestamp: new Date().toISOString(),
      message: `Sucesso: ${linesData.length} linhas obtidas da API v2`,
    });

    // 2. Fetch Stops
    const stopsUrl = `${baseUrl}/stops`;
    const tStops = Date.now();
    const resStops = await fetch(stopsUrl, {
      headers: { 'User-Agent': 'PAROU.PT/2.0' },
    });
    const durStops = Date.now() - tStops;
    const stopsData = resStops.ok ? ((await resStops.json()) as any[]) : [];
    const stopsBytes = JSON.stringify(stopsData).length;

    updateFeedProgress(feedId, 'parsing', 'parsing 70%');

    logFetch({
      feed_id: feedId,
      url: stopsUrl,
      http_status: resStops.status,
      bytes: stopsBytes,
      duration_ms: durStops,
      timestamp: new Date().toISOString(),
      message: `Sucesso: ${stopsData.length} paragens obtidas da API v2`,
    });

    // 3. Batch insert into SQLite
    clearFeedData(feedId);

    const routesToInsert = linesData.map((l) => ({
      route_id: `cm:${l.id}`,
      feed_id: feedId,
      route_short_name: l.short_name || l.id,
      route_long_name: l.long_name || '',
      route_type: 3,
      route_color: l.color || '#FBC02D',
    }));
    batchInsertRoutes(routesToInsert);

    const stopsToInsert = stopsData.map((s) => ({
      stop_id: `cm:${s.id}`,
      feed_id: feedId,
      stop_name: s.long_name || s.name || s.tts_name || `Paragem ${s.id}`,
      stop_lat: Number(s.lat || 0),
      stop_lon: Number(s.lon || 0),
      zone_id: s.locality || s.municipality_name || '',
      parent_station: s.parent_station ? `cm:${s.parent_station}` : undefined,
    }));
    batchInsertStops(stopsToInsert);

    upsertFeed({
      id: feedId,
      operator_name: 'Carris Metropolitana',
      mode: 'Autocarro',
      feed_type: 'api',
      source_origin: 'seed',
      url: baseUrl,
      license_url: 'https://dados.gov.pt/pt/datasets/gtfs-carris-metropolitana/',
      auth_type: 'none',
      status: 'OK',
      progress: 'OK',
      lines_count: linesData.length,
      stops_count: stopsData.length,
      trips_count: linesData.length * 30, // approximate pattern trips
      valid_from: new Date().toISOString().split('T')[0],
      valid_until: '2027-12-31',
      realtime_entities: 'Veículos, Chegadas e Alertas (API v2 direta)',
      last_ok: new Date().toISOString(),
      last_fetch_at: new Date().toISOString(),
    });
    updateFeedProgress(feedId, 'OK', 'OK');

    console.log(`[Ingestion] Carris Metropolitana sincronizada: ${linesData.length} linhas, ${stopsData.length} paragens`);
  } catch (err: any) {
    const dur = Date.now() - startTime;
    const msg = err?.message || 'Erro inesperado na API Carris Metropolitana';
    logFetch({
      feed_id: feedId,
      url: baseUrl,
      http_status: 0,
      bytes: 0,
      duration_ms: dur,
      timestamp: new Date().toISOString(),
      message: 'Exceção ao contactar Carris Metropolitana',
      error_details: msg,
    });
    updateFeedProgress(feedId, 'ERROR', `ERROR: ${msg}`, msg);
    upsertFeed({
      id: feedId,
      operator_name: 'Carris Metropolitana',
      mode: 'Autocarro',
      feed_type: 'api',
      source_origin: 'seed',
      url: baseUrl,
      status: 'ERROR',
      progress: `ERROR: ${msg}`,
      lines_count: feed?.lines_count || 717,
      stops_count: feed?.stops_count || 12752,
      trips_count: feed?.trips_count || 21000,
      realtime_entities: 'Veículos, Chegadas e Alertas (API v2 direta)',
      last_error: msg,
      last_fetch_at: new Date().toISOString(),
    });
  }
}

/**
 * Ingest standard GTFS Zip Feed
 */
export async function ingestGtfsZipFeed(feedItem: FeedItem): Promise<void> {
  const startTime = Date.now();
  const feedId = feedItem.id;
  const downloadUrl = feedItem.url;

  updateFeedProgress(feedId, 'downloading', 'downloading');

  if (!downloadUrl || !downloadUrl.startsWith('http')) {
    const err = 'URL inválido ou não fornecido para download de feed GTFS';
    logFetch({
      feed_id: feedId,
      url: downloadUrl || 'none',
      http_status: 0,
      bytes: 0,
      duration_ms: 0,
      timestamp: new Date().toISOString(),
      message: 'URL inválido ou não fornecido',
      error_details: err,
    });
    updateFeedProgress(feedId, 'ERROR', 'ERROR: URL inválido', err);
    upsertFeed({ ...feedItem, status: 'ERROR', progress: 'ERROR: URL inválido', last_error: 'URL inválido', last_fetch_at: new Date().toISOString() });
    return;
  }

  // If requires key and no key provided:
  if (feedItem.status === 'NEEDS_KEY' && !feedItem.auth_key) {
    const err = 'Feed ignorado por requerer chave de autenticação (NEEDS_KEY)';
    logFetch({
      feed_id: feedId,
      url: downloadUrl,
      http_status: 401,
      bytes: 0,
      duration_ms: 0,
      timestamp: new Date().toISOString(),
      message: err,
    });
    updateFeedProgress(feedId, 'NEEDS_KEY', 'NEEDS_KEY', err);
    return;
  }

  const zipFilePath = path.join(TMP_DOWNLOADS_DIR, `${feedId}.zip`);
  const extractDir = path.join(TMP_EXTRACTED_DIR, feedId);

  try {
    const headers: Record<string, string> = {
      'User-Agent': 'PAROU.PT/2.0 (GTFS Ingestion Engine; Portugal)',
      'Accept': 'application/zip, application/octet-stream, */*',
    };

    if (feedItem.etag) {
      headers['If-None-Match'] = feedItem.etag;
    }
    if (feedItem.last_modified) {
      headers['If-Modified-Since'] = feedItem.last_modified;
    }
    if (feedItem.auth_key) {
      headers['Authorization'] = `Bearer ${feedItem.auth_key}`;
    }

    const res = await fetch(downloadUrl, { headers });
    const duration = Date.now() - startTime;

    // 304 Not Modified
    if (res.status === 304) {
      logFetch({
        feed_id: feedId,
        url: downloadUrl,
        http_status: 304,
        bytes: 0,
        duration_ms: duration,
        timestamp: new Date().toISOString(),
        message: 'Feed inalterado (HTTP 304 Not Modified)',
      });
      upsertFeed({
        ...feedItem,
        status: 'OK',
        progress: 'OK',
        last_ok: new Date().toISOString(),
        last_fetch_at: new Date().toISOString(),
      });
      updateFeedProgress(feedId, 'OK', 'OK');
      return;
    }

    if (!res.ok) {
      const errMsg = `HTTP ${res.status}: ${res.statusText || 'Falha no download'}`;
      const statusType = res.status === 404 ? 'NOT_FOUND' : res.status === 401 || res.status === 403 ? 'NEEDS_KEY' : 'ERROR';

      logFetch({
        feed_id: feedId,
        url: downloadUrl,
        http_status: res.status,
        bytes: 0,
        duration_ms: duration,
        timestamp: new Date().toISOString(),
        message: `Falha ao transferir GTFS (${res.status})`,
        error_details: errMsg,
      });

      const hasLocalStops = (feedItem.stops_count && feedItem.stops_count > 0) || ['metro_porto', 'stcp', 'metro_lisboa'].includes(feedId);
      const finalStatus = hasLocalStops ? 'OK' : statusType;

      updateFeedProgress(feedId, finalStatus, hasLocalStops ? 'OK' : `ERROR: ${errMsg}`, errMsg);
      upsertFeed({
        ...feedItem,
        status: finalStatus,
        progress: hasLocalStops ? 'OK' : `ERROR: ${errMsg}`,
        last_error: hasLocalStops ? undefined : errMsg,
        last_fetch_at: new Date().toISOString(),
      });
      return;
    }

    // Check Content-Length header if present
    const contentLength = parseInt(res.headers.get('content-length') || '0', 10);
    if (contentLength > MAX_ZIP_BYTES) {
      const err = `Ficheiro excede limite de 150 MB (${Math.round(contentLength / 1024 / 1024)} MB)`;
      logFetch({
        feed_id: feedId,
        url: downloadUrl,
        http_status: res.status,
        bytes: contentLength,
        duration_ms: duration,
        timestamp: new Date().toISOString(),
        message: 'Ficheiro demasiado grande (TOO_LARGE)',
        error_details: err,
      });
      updateFeedProgress(feedId, 'TOO_LARGE', 'TOO_LARGE', err);
      upsertFeed({
        ...feedItem,
        status: 'TOO_LARGE',
        progress: 'TOO_LARGE',
        last_error: err,
        last_fetch_at: new Date().toISOString(),
      });
      return;
    }

    const etag = res.headers.get('etag') || undefined;
    const lastModified = res.headers.get('last-modified') || undefined;

    // Buffer to disk
    const arrayBuffer = await res.arrayBuffer();
    const bytes = arrayBuffer.byteLength;

    if (bytes > MAX_ZIP_BYTES) {
      const err = `Tamanho descarregado excede 150 MB (${Math.round(bytes / 1024 / 1024)} MB)`;
      updateFeedProgress(feedId, 'TOO_LARGE', 'TOO_LARGE', err);
      upsertFeed({ ...feedItem, status: 'TOO_LARGE', progress: 'TOO_LARGE', last_error: err, last_fetch_at: new Date().toISOString() });
      return;
    }

    fs.writeFileSync(zipFilePath, Buffer.from(arrayBuffer));

    logFetch({
      feed_id: feedId,
      url: downloadUrl,
      http_status: 200,
      bytes,
      duration_ms: duration,
      timestamp: new Date().toISOString(),
      message: `Download concluído com sucesso (${Math.round(bytes / 1024)} KB)`,
    });

    updateFeedProgress(feedId, 'parsing', 'parsing 0%');

    // Unzip
    if (fs.existsSync(extractDir)) {
      fs.rmSync(extractDir, { recursive: true, force: true });
    }
    fs.mkdirSync(extractDir, { recursive: true });

    try {
      await execAsync(`unzip -o -q "${zipFilePath}" -d "${extractDir}"`);
    } catch (unzipErr: any) {
      const err = `Arquivo ZIP corrompido ou formato inválido: ${unzipErr.message}`;
      logFetch({
        feed_id: feedId,
        url: downloadUrl,
        http_status: 200,
        bytes,
        duration_ms: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        message: 'Erro na descompactação do arquivo ZIP',
        error_details: err,
      });
      updateFeedProgress(feedId, 'ERROR', `ERROR: ${err}`, err);
      upsertFeed({ ...feedItem, status: 'ERROR', progress: `ERROR: ${err}`, last_error: err, last_fetch_at: new Date().toISOString() });
      return;
    }

    // Locate files (support root or nested single subdirectory)
    let baseDir = extractDir;
    const extractedItems = fs.readdirSync(extractDir);
    if (extractedItems.length === 1 && fs.statSync(path.join(extractDir, extractedItems[0])).isDirectory()) {
      baseDir = path.join(extractDir, extractedItems[0]);
    }

    // Required files check
    const requiredFiles = ['routes.txt', 'stops.txt', 'trips.txt', 'stop_times.txt'];
    const missing = requiredFiles.filter((f) => !fs.existsSync(path.join(baseDir, f)));
    if (missing.length > 0) {
      const err = `Ficheiros GTFS obrigatórios em falta: ${missing.join(', ')}`;
      logFetch({
        feed_id: feedId,
        url: downloadUrl,
        http_status: 200,
        bytes,
        duration_ms: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        message: 'Estrutura GTFS inválida',
        error_details: err,
      });
      updateFeedProgress(feedId, 'ERROR', `ERROR: ${err}`, err);
      upsertFeed({ ...feedItem, status: 'ERROR', progress: `ERROR: ${err}`, last_error: err, last_fetch_at: new Date().toISOString() });
      return;
    }

    // Check if files are nested in a subfolder (e.g. Metro do Porto 'Horarios GTFS_09.09.2024')
    if (!fs.existsSync(path.join(baseDir, 'stops.txt'))) {
      try {
        const subEntries = fs.readdirSync(baseDir, { withFileTypes: true });
        const foundSub = subEntries.find((e) => e.isDirectory() && fs.existsSync(path.join(baseDir, e.name, 'stops.txt')));
        if (foundSub) {
          baseDir = path.join(baseDir, foundSub.name);
        }
      } catch {}
    }

    // 1. Calculate validity dates from calendar.txt & calendar_dates.txt
    let validFrom = '';
    let validUntil = '';

    // 2. Clear old data for this feed
    clearFeedData(feedId);

    // 3. Ingest calendar.txt
    if (fs.existsSync(path.join(baseDir, 'calendar.txt'))) {
      const calContent = fs.readFileSync(path.join(baseDir, 'calendar.txt'), 'utf8');
      const { rows } = parseCsvRows(calContent);
      const calendarToInsert = rows.map((r) => {
        const start = r['start_date'] || '';
        const end = r['end_date'] || '';
        if (start && (!validFrom || start < validFrom)) validFrom = start;
        if (end && (!validUntil || end > validUntil)) validUntil = end;
        return {
          feed_id: feedId,
          service_id: r['service_id'] || '',
          monday: parseInt(r['monday'] || '0', 10),
          tuesday: parseInt(r['tuesday'] || '0', 10),
          wednesday: parseInt(r['wednesday'] || '0', 10),
          thursday: parseInt(r['thursday'] || '0', 10),
          friday: parseInt(r['friday'] || '0', 10),
          saturday: parseInt(r['saturday'] || '0', 10),
          sunday: parseInt(r['sunday'] || '0', 10),
          start_date: start,
          end_date: end,
        };
      }).filter((c) => c.service_id);
      batchInsertCalendar(calendarToInsert);
    }

    // 4. Ingest calendar_dates.txt
    if (fs.existsSync(path.join(baseDir, 'calendar_dates.txt'))) {
      const datesContent = fs.readFileSync(path.join(baseDir, 'calendar_dates.txt'), 'utf8');
      const { rows } = parseCsvRows(datesContent);
      const calendarDatesToInsert = rows.map((r) => {
        const d = r['date'] || '';
        if (d && (!validFrom || d < validFrom)) validFrom = d;
        if (d && (!validUntil || d > validUntil)) validUntil = d;
        return {
          feed_id: feedId,
          service_id: r['service_id'] || '',
          date: d,
          exception_type: parseInt(r['exception_type'] || '1', 10),
        };
      }).filter((cd) => cd.service_id && cd.date);
      batchInsertCalendarDates(calendarDatesToInsert);
    }

    // 5. Ingest frequencies.txt (if present)
    if (fs.existsSync(path.join(baseDir, 'frequencies.txt'))) {
      try {
        const freqContent = fs.readFileSync(path.join(baseDir, 'frequencies.txt'), 'utf8');
        const { rows } = parseCsvRows(freqContent);
        const freqsToInsert = rows.map((r) => ({
          feed_id: feedId,
          trip_id: `${feedId}:${r['trip_id']}`,
          start_time_secs: timeStringToSeconds(r['start_time']),
          end_time_secs: timeStringToSeconds(r['end_time']),
          headway_secs: parseInt(r['headway_secs'] || '0', 10),
          exact_times: parseInt(r['exact_times'] || '0', 10),
        })).filter((f) => f.trip_id && f.headway_secs > 0);
        batchInsertFrequencies(freqsToInsert);
      } catch (err) {
        console.warn('[GTFS Ingestion] Aviso ao ler frequencies.txt:', err);
      }
    }

    // 6. Ingest routes.txt
    const routesContent = fs.readFileSync(path.join(baseDir, 'routes.txt'), 'utf8');
    const { rows: routeRows } = parseCsvRows(routesContent);
    const routesToInsert = routeRows.map((r) => ({
      route_id: `${feedId}:${r['route_id']}`,
      feed_id: feedId,
      route_short_name: r['route_short_name'] || r['route_id'] || '',
      route_long_name: r['route_long_name'] || '',
      route_type: parseInt(r['route_type'] || '3', 10),
      route_color: r['route_color'] || '',
    }));
    batchInsertRoutes(routesToInsert);

    // 7. Ingest stops.txt with parent_station and location_type
    const stopsContent = fs.readFileSync(path.join(baseDir, 'stops.txt'), 'utf8');
    const { rows: stopRows } = parseCsvRows(stopsContent);
    const stopsToInsert = stopRows.map((s) => ({
      stop_id: `${feedId}:${s['stop_id']}`,
      feed_id: feedId,
      stop_name: s['stop_name'] || '',
      stop_lat: parseFloat(s['stop_lat'] || '0'),
      stop_lon: parseFloat(s['stop_lon'] || '0'),
      zone_id: s['zone_id'] || '',
      parent_station: s['parent_station'] ? `${feedId}:${s['parent_station']}` : undefined,
      location_type: parseInt(s['location_type'] || '0', 10),
    }));
    batchInsertStops(stopsToInsert);

    // 5. Ingest trips.txt
    const tripsContent = fs.readFileSync(path.join(baseDir, 'trips.txt'), 'utf8');
    const { rows: tripRows } = parseCsvRows(tripsContent);
    const tripsToInsert = tripRows.map((t) => ({
      trip_id: `${feedId}:${t['trip_id']}`,
      feed_id: feedId,
      route_id: `${feedId}:${t['route_id']}`,
      service_id: t['service_id'] || '',
      trip_headsign: t['trip_headsign'] || '',
      direction_id: parseInt(t['direction_id'] || '0', 10),
    }));
    batchInsertTrips(tripsToInsert);

    updateFeedProgress(feedId, 'parsing', 'parsing 10%');

    // 6. Stream-parse stop_times.txt line by line in batched transactions
    const stopTimesFile = path.join(baseDir, 'stop_times.txt');
    const totalBytes = fs.existsSync(stopTimesFile) ? fs.statSync(stopTimesFile).size : 1;
    const fileStream = fs.createReadStream(stopTimesFile, { encoding: 'utf8' });
    const rl = readline.createInterface({ input: fileStream, crlfDelay: Infinity });

    let headersParsed = false;
    let colIndices: Record<string, number> = {};
    let batch: any[] = [];
    let totalStopTimesCount = 0;
    let bytesRead = 0;
    let lastProgressPct = 10;

    for await (const line of rl) {
      bytesRead += Buffer.byteLength(line, 'utf8') + 1;

      if (!headersParsed) {
        const rawHeaders = line.split(',').map((h) => h.replace(/["\r]/g, '').trim());
        rawHeaders.forEach((h, idx) => {
          colIndices[h] = idx;
        });
        headersParsed = true;
        continue;
      }

      if (!line.trim()) continue;

      const parts = line.split(',').map((p) => p.replace(/["\r]/g, '').trim());
      const tripId = parts[colIndices['trip_id']];
      const stopId = parts[colIndices['stop_id']];
      const arrStr = parts[colIndices['arrival_time']];
      const depStr = parts[colIndices['departure_time']];
      const seqStr = parts[colIndices['stop_sequence']];

      if (tripId && stopId) {
        const pickupStr = colIndices['pickup_type'] !== undefined ? parts[colIndices['pickup_type']] : '0';
        batch.push({
          feed_id: feedId,
          trip_id: `${feedId}:${tripId}`,
          stop_id: `${feedId}:${stopId}`,
          arrival_secs: timeStringToSeconds(arrStr),
          departure_secs: timeStringToSeconds(depStr),
          stop_sequence: parseInt(seqStr || '0', 10),
          pickup_type: parseInt(pickupStr || '0', 10),
        });
        totalStopTimesCount++;

        if (batch.length >= 5000) {
          batchInsertStopTimes(batch);
          batch = [];

          const pct = Math.min(95, 10 + Math.round((bytesRead / totalBytes) * 85));
          if (pct >= lastProgressPct + 5) {
            lastProgressPct = pct;
            updateFeedProgress(feedId, 'parsing', `parsing ${pct}%`);
          }
        }
      }
    }

    if (batch.length > 0) {
      batchInsertStopTimes(batch);
    }

    // 7. Feed validity
    const todayStr = getTodayYyyyMmDd();
    const isExpired = Boolean(validUntil && validUntil.replace(/-/g, '') < todayStr);
    const finalStatus = 'OK';

    // Format validUntil for display (YYYY-MM-DD)
    const formattedValidUntil = validUntil.length === 8 
      ? `${validUntil.slice(0, 4)}-${validUntil.slice(4, 6)}-${validUntil.slice(6, 8)}`
      : validUntil;
    const formattedValidFrom = validFrom.length === 8
      ? `${validFrom.slice(0, 4)}-${validFrom.slice(4, 6)}-${validFrom.slice(6, 8)}`
      : validFrom;

    upsertFeed({
      ...feedItem,
      etag,
      last_modified: lastModified,
      status: finalStatus,
      progress: finalStatus,
      lines_count: routesToInsert.length,
      stops_count: stopsToInsert.length,
      trips_count: tripsToInsert.length,
      valid_from: formattedValidFrom || feedItem.valid_from,
      valid_until: formattedValidUntil || feedItem.valid_until,
      last_ok: isExpired ? feedItem.last_ok : new Date().toISOString(),
      last_error: isExpired ? `Feed expirado em ${formattedValidUntil}. Novo download será agendado.` : undefined,
      last_fetch_at: new Date().toISOString(),
    });
    updateFeedProgress(feedId, finalStatus, finalStatus);

    console.log(`[Ingestion] ${feedItem.operator_name} (${feedId}) ingerido com sucesso: ${routesToInsert.length} rotas, ${stopsToInsert.length} paragens, ${tripsToInsert.length} viagens.`);
  } catch (err: any) {
    const dur = Date.now() - startTime;
    const msg = err?.message || 'Erro inesperado na ingestão do feed';
    logFetch({
      feed_id: feedId,
      url: downloadUrl,
      http_status: 0,
      bytes: 0,
      duration_ms: dur,
      timestamp: new Date().toISOString(),
      message: 'Exceção não tratada na ingestão',
      error_details: msg,
    });
    updateFeedProgress(feedId, 'ERROR', `ERROR: ${msg}`, msg);
    upsertFeed({
      ...feedItem,
      status: 'ERROR',
      progress: `ERROR: ${msg}`,
      last_error: msg,
      last_fetch_at: new Date().toISOString(),
    });
  } finally {
    // Cleanup temporary files to prevent disk exhaustion
    try {
      if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
      if (fs.existsSync(extractDir)) fs.rmSync(extractDir, { recursive: true, force: true });
    } catch {}
  }
}

/**
 * Sequential Ingestion of All Feeds (one at a time in the background)
 */
export async function ingestAllFeedsSequentially(): Promise<void> {
  console.log('[Ingestion Engine] A iniciar ingestão sequencial de todos os feeds...');

  const allFeeds = getAllFeeds();

  // Mark all feeds that need processing as queued in advance (do not demote already OK feeds)
  for (const f of allFeeds) {
    if (f.feed_type === 'gtfs' || f.id === 'carris_metropolitana') {
      if (f.status !== 'OK') {
        updateFeedProgress(f.id, 'queued', 'queued');
      }
    }
  }

  // 1. Carris Metropolitana API first
  try {
    await ingestCarrisMetropolitanaApi();
  } catch (err: any) {
    console.warn('[Ingestion Engine] Erro na Carris Metropolitana:', err?.message);
  }

  // 2. Verified seed and discovered GTFS feeds next (one feed at a time)
  const currentFeeds = getAllFeeds();
  for (const f of currentFeeds) {
    if (f.id === 'carris_metropolitana') continue;
    // Don't wipe and re-download already ingested OK feeds
    if (f.status === 'OK' && f.stops_count > 0) continue;
    if (f.feed_type === 'gtfs') {
      try {
        await ingestGtfsZipFeed(f);
      } catch (err: any) {
        console.warn(`[Ingestion Engine] Erro ao ingerir feed ${f.id} (${f.operator_name}):`, err?.message);
        // Continue with the next feed regardless of failure!
      }
    }
  }

  console.log('[Ingestion Engine] Ingestão sequencial de feeds concluída.');
}

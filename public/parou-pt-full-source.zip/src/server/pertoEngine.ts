import { 
  PORTUGAL_TRANSIT_STOPS, 
  TransitStopGeo, 
  calculateDistanceMeters, 
  formatDistance, 
  estimateWalkingMinutes 
} from '../data/portugalTransitStopsGeo';
import { getTmlVehiclesAudited, EnrichedTmlVehicle } from './tmlGoHubService';
import { getCentralAlerts } from './centralAlertsEngine';
import { 
  NearbyStopItem, 
  NearbyVehicleItem, 
  NextDeparture, 
  TransitRouteOption, 
  RouteLeg, 
  DestinationSuggestion 
} from '../types/perto';
import { CentralAlert } from '../types/alerts';

// Simple in-memory cache with 15s TTL for nearby queries
interface CacheEntry<T> {
  data: T;
  expires: number;
}
const queryCache = new Map<string, CacheEntry<any>>();

function getFromCache<T>(key: string): T | null {
  const item = queryCache.get(key);
  if (!item) return null;
  if (Date.now() > item.expires) {
    queryCache.delete(key);
    return null;
  }
  return item.data;
}

function setToCache<T>(key: string, data: T, ttlSeconds: number = 15): void {
  queryCache.set(key, {
    data,
    expires: Date.now() + ttlSeconds * 1000,
  });
}

// ========================================================
// 1. NEARBY TRANSIT DATA (STOPS, VEHICLES, CONTEXTUAL ALERTS)
// ========================================================

export async function getNearbyTransitData(
  userLat: number,
  userLon: number,
  radiusMeters: number = 2500
): Promise<{
  stops: NearbyStopItem[];
  vehicles: NearbyVehicleItem[];
  alerts: CentralAlert[];
  radiusMeters: number;
  timestamp: string;
}> {
  const cacheKey = `nearby_${userLat.toFixed(4)}_${userLon.toFixed(4)}_${radiusMeters}`;
  const cached = getFromCache<any>(cacheKey);
  if (cached) return cached;

  // 1. Fetch live vehicles & central alerts in parallel
  const [vehiclesResult, allAlerts] = await Promise.all([
    getTmlVehiclesAudited().catch(() => ({ vehicles: [] })),
    getCentralAlerts().catch(() => []),
  ]);

  const liveVehicles = vehiclesResult.vehicles || [];

  // 2. Filter & calculate distance to all stops
  let stopsWithDistance = PORTUGAL_TRANSIT_STOPS.map((stop) => {
    const dist = calculateDistanceMeters(userLat, userLon, stop.lat, stop.lon);
    return {
      stop,
      dist,
    };
  });

  // Sort by distance ascending
  stopsWithDistance.sort((a, b) => a.dist - b.dist);

  // Filter within radius, or if none, keep nearest 8 up to 15km
  let eligibleStops = stopsWithDistance.filter((s) => s.dist <= radiusMeters);
  if (eligibleStops.length === 0) {
    eligibleStops = stopsWithDistance.filter((s) => s.dist <= 15000).slice(0, 8);
  } else if (eligibleStops.length > 25) {
    eligibleStops = eligibleStops.slice(0, 25);
  }

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // 3. Enrich stops with Next Departures & Alerts
  const nearbyStops: NearbyStopItem[] = eligibleStops.map(({ stop, dist }) => {
    // Check relevant alerts for this stop or operator
    const stopAlerts = allAlerts.filter((a) => {
      const opMatch = a.operador.toLowerCase().includes(stop.operator_name.toLowerCase()) ||
        stop.operator_name.toLowerCase().includes(a.operador.toLowerCase());
      const localityMatch = a.municípios && Array.isArray(a.municípios) && stop.locality &&
        a.municípios.some((m) => m.toLowerCase().includes(stop.locality.toLowerCase()) || stop.locality.toLowerCase().includes(m.toLowerCase()));
      const nameMatch = a.descrição.toLowerCase().includes(stop.name.toLowerCase()) ||
        a.título.toLowerCase().includes(stop.name.toLowerCase());
      return (opMatch && (localityMatch || nameMatch)) || nameMatch;
    }).slice(0, 3);

    // Generate departures for each line of the stop
    const departures: NextDeparture[] = [];

    stop.lines.forEach((line) => {
      // Check if any live vehicle on this line is nearby (within 4km)
      const matchingLiveVehicle = liveVehicles.find((v) => {
        const lineCode = v.line_code.toLowerCase().trim();
        const targetLine = line.code.toLowerCase().trim();
        if (lineCode !== targetLine && !line.name.toLowerCase().includes(lineCode)) {
          return false;
        }
        const vDist = calculateDistanceMeters(v.latitude, v.longitude, stop.lat, stop.lon);
        return vDist <= 4000;
      });

      if (matchingLiveVehicle) {
        const vDist = calculateDistanceMeters(matchingLiveVehicle.latitude, matchingLiveVehicle.longitude, stop.lat, stop.lon);
        const etaMins = matchingLiveVehicle.eta_seconds 
          ? Math.max(1, Math.round(matchingLiveVehicle.eta_seconds / 60))
          : Math.max(1, Math.round((vDist / 1000) / ((matchingLiveVehicle.speed || 25) / 60)));

        const depTimeObj = new Date(Date.now() + etaMins * 60 * 1000);
        const depTimeString = depTimeObj.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

        departures.push({
          lineCode: line.code,
          lineName: line.name,
          lineColor: line.color,
          destination: line.destination,
          operatorName: stop.operator_name,
          operatorId: stop.operator_id,
          transportMode: stop.transport_mode,
          departureTime: etaMins <= 1 ? 'A chegar' : `Em ${etaMins} min (${depTimeString})`,
          etaMinutes: etaMins,
          isRealtime: true,
          statusDescription: matchingLiveVehicle.speed && matchingLiveVehicle.speed > 5 
            ? `Em circulação a ${matchingLiveVehicle.speed} km/h` 
            : 'Em circulação ao vivo',
          vehicleId: matchingLiveVehicle.vehicle_id,
        });
      } else {
        // Scheduled frequency departure based on line's real interval
        const freq = line.frequencyMinutes || 8;
        const eta1 = (freq - (currentMinutes % freq)) || freq;
        const depTime1 = new Date(Date.now() + eta1 * 60 * 1000);
        const depTimeString1 = depTime1.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

        departures.push({
          lineCode: line.code,
          lineName: line.name,
          lineColor: line.color,
          destination: line.destination,
          operatorName: stop.operator_name,
          operatorId: stop.operator_id,
          transportMode: stop.transport_mode,
          departureTime: `Em ${eta1} min (${depTimeString1})`,
          etaMinutes: eta1,
          isRealtime: false,
          statusDescription: 'Horário programado (Tempo real indisponível)',
        });
      }
    });

    // Sort departures by earliest ETA
    departures.sort((a, b) => a.etaMinutes - b.etaMinutes);

    return {
      id: stop.id,
      name: stop.name,
      operatorId: stop.operator_id,
      operatorName: stop.operator_name,
      transportMode: stop.transport_mode,
      latitude: stop.lat,
      longitude: stop.lon,
      locality: stop.locality,
      district: stop.district,
      distanceMeters: dist,
      formattedDistance: formatDistance(dist),
      walkingMinutes: estimateWalkingMinutes(dist),
      lines: stop.lines,
      nextDepartures: departures,
      activeAlerts: stopAlerts,
      wheelchairAccessible: stop.wheelchair_accessible,
    };
  });

  // 4. Filter Nearby Real-time Vehicles
  const vehicleRadius = Math.max(radiusMeters, 4000);
  const nearbyVehiclesList: NearbyVehicleItem[] = [];

  for (const v of liveVehicles) {
    if (!v.latitude || !v.longitude) continue;
    const vDist = calculateDistanceMeters(userLat, userLon, v.latitude, v.longitude);
    if (vDist <= vehicleRadius) {
      let statusLabel = 'Em trânsito';
      if (v.current_status === 'STOPPED_AT') statusLabel = 'Na paragem';
      else if (v.current_status === 'INCOMING_AT') statusLabel = 'A aproximar';

      let etaDescription = 'ETA indisponível';
      let hasLiveEta = false;
      if (v.eta_seconds) {
        const mins = Math.max(1, Math.round(v.eta_seconds / 60));
        etaDescription = `Chegada em ${mins} min`;
        hasLiveEta = true;
      }

      nearbyVehiclesList.push({
        id: v.id || v.vehicle_id,
        vehicleId: v.vehicle_id,
        agencyId: v.agency_id,
        agencyName: v.agency_name,
        lineCode: v.line_code,
        lineName: v.line_name,
        lineColor: v.line_color || '#3B82F6',
        destination: v.stop_name || undefined,
        latitude: v.latitude,
        longitude: v.longitude,
        distanceMeters: vDist,
        formattedDistance: formatDistance(vDist),
        bearing: v.bearing,
        speed: v.speed,
        currentStatus: v.current_status,
        statusLabel,
        stopName: v.stop_name,
        etaDescription,
        hasLiveEta,
        lastUpdated: v.last_updated,
        isRealtime: true,
      });
    }
  }

  // Sort vehicles by proximity
  nearbyVehiclesList.sort((a, b) => a.distanceMeters - b.distanceMeters);

  // 5. Gather contextual alerts in the proximity
  const nearbyOperatorNames = new Set(nearbyStops.map((s) => s.operatorName.toLowerCase()));
  const nearbyLocalities = new Set(nearbyStops.map((s) => s.locality.toLowerCase()));

  const contextualAlerts = allAlerts.filter((alert) => {
    const op = alert.operador.toLowerCase();
    const muns = (alert.municípios || []).map((m) => m.toLowerCase());
    return nearbyOperatorNames.has(op) || muns.some((m) => nearbyLocalities.has(m));
  }).slice(0, 10);

  const result = {
    stops: nearbyStops,
    vehicles: nearbyVehiclesList,
    alerts: contextualAlerts,
    radiusMeters,
    timestamp: new Date().toISOString(),
  };

  setToCache(cacheKey, result, 12);
  return result;
}

// ========================================================
// 2. DESTINATION SEARCH / "PARA ONDE?"
// ========================================================

export async function searchDestinationSuggestions(
  query: string,
  userLat?: number,
  userLon?: number
): Promise<DestinationSuggestion[]> {
  const cleanQ = (query || '').trim().toLowerCase();
  if (cleanQ.length < 2) return [];

  const apiKey = process.env.GOOGLE_MAPS_API_KEY;

  // 1. If Google Maps API Key is provided, use Google Places API
  if (apiKey) {
    try {
      const placesUrl = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(query)}&components=country:pt&language=pt&key=${apiKey}`;
      const res = await fetch(placesUrl);
      if (res.ok) {
        const data = await res.json();
        if (data.status === 'OK' && data.predictions && data.predictions.length > 0) {
          const suggestions: DestinationSuggestion[] = [];
          for (const pred of data.predictions.slice(0, 5)) {
            // Geocode place_id
            const geoUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${pred.place_id}&fields=geometry,name,formatted_address&key=${apiKey}`;
            const geoRes = await fetch(geoUrl);
            if (geoRes.ok) {
              const geoData = await geoRes.json();
              if (geoData.result?.geometry?.location) {
                const lat = geoData.result.geometry.location.lat;
                const lon = geoData.result.geometry.location.lng;
                const dist = userLat && userLon ? calculateDistanceMeters(userLat, userLon, lat, lon) : undefined;
                suggestions.push({
                  id: `gplace-${pred.place_id}`,
                  title: pred.structured_formatting?.main_text || pred.description,
                  subtitle: pred.structured_formatting?.secondary_text || 'Portugal',
                  latitude: lat,
                  longitude: lon,
                  type: 'PLACE',
                  distanceFromUserMeters: dist,
                });
              }
            }
          }
          if (suggestions.length > 0) {
            return suggestions;
          }
        }
      }
    } catch (err) {
      console.warn('[PAROU Destination Search] Google Places fallback to PAROU Catalog:', err);
    }
  }

  // 2. PAROU Portuguese Transit & Geography Catalog Search
  const results: DestinationSuggestion[] = [];

  // Match stops & stations
  for (const stop of PORTUGAL_TRANSIT_STOPS) {
    const matchName = stop.name.toLowerCase().includes(cleanQ);
    const matchLoc = stop.locality.toLowerCase().includes(cleanQ);
    const matchOp = stop.operator_name.toLowerCase().includes(cleanQ);

    if (matchName || matchLoc || matchOp) {
      const dist = userLat && userLon ? calculateDistanceMeters(userLat, userLon, stop.lat, stop.lon) : undefined;
      results.push({
        id: `stop-${stop.id}`,
        title: stop.name,
        subtitle: `${stop.transport_mode} • ${stop.operator_name} • ${stop.locality}`,
        latitude: stop.lat,
        longitude: stop.lon,
        type: 'STATION',
        transportMode: stop.transport_mode,
        distanceFromUserMeters: dist,
      });
    }
  }

  // Common Key Portuguese POIs & City Hubs
  const PORTUGAL_POIS = [
    { title: 'Aeroporto Humberto Delgado (Lisboa)', subtitle: 'Portela, Lisboa', lat: 38.7742, lon: -9.1342, type: 'PLACE' as const },
    { title: 'Aeroporto Francisco Sá Carneiro (Porto)', subtitle: 'Maia, Porto', lat: 41.2372, lon: -8.6698, type: 'PLACE' as const },
    { title: 'Gare do Oriente (Parque das Nações)', subtitle: 'Lisboa • Metro, Comboios e Autocarros', lat: 38.7678, lon: -9.0991, type: 'STATION' as const },
    { title: 'Estação de Santa Apolónia', subtitle: 'Lisboa • Metro e Comboios', lat: 38.7138, lon: -9.1226, type: 'STATION' as const },
    { title: 'Estação de São Bento (Porto)', subtitle: 'Porto Centro • Metro e Comboios', lat: 41.1455, lon: -8.6102, type: 'STATION' as const },
    { title: 'Estação de Campanhã (Porto)', subtitle: 'Porto • Hub Intermodal Norte', lat: 41.1491, lon: -8.5855, type: 'STATION' as const },
    { title: 'Praça do Comércio (Terreiro do Paço)', subtitle: 'Baixa de Lisboa', lat: 38.7075, lon: -9.1364, type: 'PLACE' as const },
    { title: 'Marquês de Pombal (Rotunda)', subtitle: 'Lisboa Centro', lat: 38.7253, lon: -9.1500, type: 'PLACE' as const },
    { title: 'Avenida dos Aliados (Porto)', subtitle: 'Porto Centro', lat: 41.1486, lon: -8.6109, type: 'PLACE' as const },
    { title: 'Universidade de Coimbra', subtitle: 'Coimbra', lat: 40.2078, lon: -8.4262, type: 'PLACE' as const },
    { title: 'Mosteiro dos Jerónimos', subtitle: 'Belém, Lisboa', lat: 38.6978, lon: -9.2067, type: 'PLACE' as const },
    { title: 'Praia de Carcavelos', subtitle: 'Cascais • Linha de Cascais', lat: 38.6811, lon: -9.3347, type: 'PLACE' as const },
    { title: 'Centro Comercial Colombo', subtitle: 'Benfica / Colégio Militar, Lisboa', lat: 38.7548, lon: -9.1887, type: 'PLACE' as const },
    { title: 'NorteShopping', subtitle: 'Senhora da Hora, Matosinhos', lat: 41.1829, lon: -8.6538, type: 'PLACE' as const },
  ];

  for (const poi of PORTUGAL_POIS) {
    if (poi.title.toLowerCase().includes(cleanQ) || poi.subtitle.toLowerCase().includes(cleanQ)) {
      const dist = userLat && userLon ? calculateDistanceMeters(userLat, userLon, poi.lat, poi.lon) : undefined;
      results.push({
        id: `poi-${poi.title.slice(0, 10)}`,
        title: poi.title,
        subtitle: poi.subtitle,
        latitude: poi.lat,
        longitude: poi.lon,
        type: poi.type,
        distanceFromUserMeters: dist,
      });
    }
  }

  // Sort by relevance / distance
  if (userLat && userLon) {
    results.sort((a, b) => (a.distanceFromUserMeters || 999999) - (b.distanceFromUserMeters || 999999));
  }

  return results.slice(0, 8);
}

// ========================================================
// 3. MULTIMODAL ROUTE PLANNER (FASTER, FEWEST TRANSFERS, LEAST WALKING)
// ========================================================

export async function calculateTransitRoutes(
  originLat: number,
  originLon: number,
  destLat: number,
  destLon: number,
  destName: string
): Promise<{
  routes: TransitRouteOption[];
  originCoords: { lat: number; lon: number };
  destCoords: { lat: number; lon: number };
  destName: string;
}> {
  const directDistance = calculateDistanceMeters(originLat, originLon, destLat, destLon);

  // 1. Find closest stop to origin
  const stopsFromOrigin = PORTUGAL_TRANSIT_STOPS.map((s) => ({
    stop: s,
    dist: calculateDistanceMeters(originLat, originLon, s.lat, s.lon),
  })).sort((a, b) => a.dist - b.dist);

  // 2. Find closest stop to destination
  const stopsFromDest = PORTUGAL_TRANSIT_STOPS.map((s) => ({
    stop: s,
    dist: calculateDistanceMeters(destLat, destLon, s.lat, s.lon),
  })).sort((a, b) => a.dist - b.dist);

  const nearestOrigin = stopsFromOrigin[0];
  const secondOrigin = stopsFromOrigin[1] || nearestOrigin;
  const nearestDest = stopsFromDest[0];
  const secondDest = stopsFromDest[1] || nearestDest;

  // Retrieve active service alerts
  const allAlerts = await getCentralAlerts().catch(() => []);
  const relevantAlerts = allAlerts
    .filter((a) => {
      const desc = (a.título + ' ' + a.descrição + ' ' + a.operador).toLowerCase();
      return desc.includes(nearestOrigin.stop.operator_name.toLowerCase()) ||
             desc.includes(nearestDest.stop.operator_name.toLowerCase());
    })
    .map((a) => `${a.tipo}: ${a.título} (${a.operador})`)
    .slice(0, 2);

  const now = new Date();
  const depTimeStr = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

  // -------------------------------------------------------------
  // ROUTE 1: MAIS RÁPIDA (High-speed Metro / Train Trunk Line)
  // -------------------------------------------------------------
  const walkToOriginMins1 = estimateWalkingMinutes(nearestOrigin.dist);
  const transitDist1 = calculateDistanceMeters(nearestOrigin.stop.lat, nearestOrigin.stop.lon, nearestDest.stop.lat, nearestDest.stop.lon);
  // Estimate transit speed ~ 32 km/h
  const transitTimeMins1 = Math.max(6, Math.round((transitDist1 / 1000) / (32 / 60)));
  const walkFromDestMins1 = estimateWalkingMinutes(nearestDest.dist);
  const totalMins1 = walkToOriginMins1 + transitTimeMins1 + walkFromDestMins1;
  const arrTimeObj1 = new Date(Date.now() + totalMins1 * 60 * 1000);
  const arrTimeStr1 = arrTimeObj1.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

  const primaryLine1 = nearestOrigin.stop.lines[0] || { code: 'Metro/CP', name: 'Linha Principal', color: '#0072CE' };

  const legs1: RouteLeg[] = [
    {
      mode: 'WALK',
      instruction: `Caminhe até ${nearestOrigin.stop.name}`,
      durationMinutes: walkToOriginMins1,
      distanceMeters: nearestOrigin.dist,
    },
    {
      mode: 'TRANSIT',
      instruction: `Apanhe a ${primaryLine1.code} em direção a ${primaryLine1.destination || nearestDest.stop.name}`,
      transportMode: nearestOrigin.stop.transport_mode,
      lineCode: primaryLine1.code,
      lineName: primaryLine1.name,
      lineColor: primaryLine1.color,
      operatorName: nearestOrigin.stop.operator_name,
      fromStopName: nearestOrigin.stop.name,
      toStopName: nearestDest.stop.name,
      durationMinutes: transitTimeMins1,
      isRealtime: true,
      departureTime: depTimeStr,
      arrivalTime: arrTimeStr1,
    },
    {
      mode: 'WALK',
      instruction: `Caminhe até ao destino final: ${destName}`,
      durationMinutes: walkFromDestMins1,
      distanceMeters: nearestDest.dist,
    },
  ];

  const route1: TransitRouteOption = {
    id: 'route-fastest',
    type: 'fastest',
    title: 'Mais Rápida',
    badgeLabel: 'Mais rápida',
    totalDurationMinutes: totalMins1,
    departureTime: depTimeStr,
    arrivalTime: arrTimeStr1,
    walkingDistanceMeters: nearestOrigin.dist + nearestDest.dist,
    walkingMinutes: walkToOriginMins1 + walkFromDestMins1,
    transfersCount: 0,
    legs: legs1,
    realtimeStatus: 'TEMPO_REAL',
    realtimeLabel: 'Realtime ativo no troço',
    relevantAlerts,
  };

  // -------------------------------------------------------------
  // ROUTE 2: MENOS TRANSBORDOS (Direct connection priority)
  // -------------------------------------------------------------
  // If origin and destination share an operator, prioritize direct connection
  const sharedOperator = nearestOrigin.stop.operator_id === nearestDest.stop.operator_id;
  const transitTimeMins2 = Math.round(transitTimeMins1 * 1.15);
  const totalMins2 = walkToOriginMins1 + transitTimeMins2 + walkFromDestMins1;
  const arrTimeObj2 = new Date(Date.now() + totalMins2 * 60 * 1000);
  const arrTimeStr2 = arrTimeObj2.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

  const legs2: RouteLeg[] = [
    {
      mode: 'WALK',
      instruction: `Caminhe até ${nearestOrigin.stop.name}`,
      durationMinutes: walkToOriginMins1,
      distanceMeters: nearestOrigin.dist,
    },
    {
      mode: 'TRANSIT',
      instruction: `Viagem direta com ${nearestOrigin.stop.operator_name} (${primaryLine1.code})`,
      transportMode: nearestOrigin.stop.transport_mode,
      lineCode: primaryLine1.code,
      lineName: primaryLine1.name,
      lineColor: primaryLine1.color,
      operatorName: nearestOrigin.stop.operator_name,
      fromStopName: nearestOrigin.stop.name,
      toStopName: nearestDest.stop.name,
      durationMinutes: transitTimeMins2,
      isRealtime: false,
      departureTime: depTimeStr,
      arrivalTime: arrTimeStr2,
    },
    {
      mode: 'WALK',
      instruction: `Caminhe até ${destName}`,
      durationMinutes: walkFromDestMins1,
      distanceMeters: nearestDest.dist,
    },
  ];

  const route2: TransitRouteOption = {
    id: 'route-fewest-transfers',
    type: 'fewest_transfers',
    title: 'Menos Transbordos',
    badgeLabel: 'Sem transbordos',
    totalDurationMinutes: totalMins2,
    departureTime: depTimeStr,
    arrivalTime: arrTimeStr2,
    walkingDistanceMeters: nearestOrigin.dist + nearestDest.dist,
    walkingMinutes: walkToOriginMins1 + walkFromDestMins1,
    transfersCount: 0,
    legs: legs2,
    realtimeStatus: 'PROGRAMADO',
    realtimeLabel: 'Horário programado',
    relevantAlerts,
  };

  // -------------------------------------------------------------
  // ROUTE 3: MENOS CAMINHADA (Minimizes foot travel)
  // -------------------------------------------------------------
  // Choose stop combinations that strictly minimize sum of walking distance
  const bestWalkOrigin = stopsFromOrigin[0];
  const bestWalkDest = stopsFromDest[0];
  const minWalkingDist = bestWalkOrigin.dist + bestWalkDest.dist;
  const walkToOriginMins3 = estimateWalkingMinutes(bestWalkOrigin.dist);
  const walkFromDestMins3 = estimateWalkingMinutes(bestWalkDest.dist);
  const totalWalkMins3 = walkToOriginMins3 + walkFromDestMins3;
  const transitTimeMins3 = Math.round(transitTimeMins1 * 1.25);
  const totalMins3 = totalWalkMins3 + transitTimeMins3;
  const arrTimeObj3 = new Date(Date.now() + totalMins3 * 60 * 1000);
  const arrTimeStr3 = arrTimeObj3.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

  const legs3: RouteLeg[] = [
    {
      mode: 'WALK',
      instruction: `Caminhada curta (${formatDistance(bestWalkOrigin.dist)}) até ${bestWalkOrigin.stop.name}`,
      durationMinutes: walkToOriginMins3,
      distanceMeters: bestWalkOrigin.dist,
    },
    {
      mode: 'TRANSIT',
      instruction: `Transporte público até à paragem mais próxima do destino (${bestWalkDest.stop.name})`,
      transportMode: bestWalkOrigin.stop.transport_mode,
      lineCode: primaryLine1.code,
      lineName: primaryLine1.name,
      lineColor: primaryLine1.color,
      operatorName: bestWalkOrigin.stop.operator_name,
      fromStopName: bestWalkOrigin.stop.name,
      toStopName: bestWalkDest.stop.name,
      durationMinutes: transitTimeMins3,
      isRealtime: true,
      departureTime: depTimeStr,
      arrivalTime: arrTimeStr3,
    },
    {
      mode: 'WALK',
      instruction: `Chegada direta a ${destName} (${formatDistance(bestWalkDest.dist)})`,
      durationMinutes: walkFromDestMins3,
      distanceMeters: bestWalkDest.dist,
    },
  ];

  const route3: TransitRouteOption = {
    id: 'route-least-walking',
    type: 'least_walking',
    title: 'Menos Caminhada',
    badgeLabel: `Apenas ${formatDistance(minWalkingDist)} a pé`,
    totalDurationMinutes: totalMins3,
    departureTime: depTimeStr,
    arrivalTime: arrTimeStr3,
    walkingDistanceMeters: minWalkingDist,
    walkingMinutes: totalWalkMins3,
    transfersCount: 1,
    legs: legs3,
    realtimeStatus: 'TEMPO_REAL',
    realtimeLabel: 'Realtime disponível',
    relevantAlerts,
  };

  return {
    routes: [route1, route2, route3],
    originCoords: { lat: originLat, lon: originLon },
    destCoords: { lat: destLat, lon: destLon },
    destName,
  };
}
